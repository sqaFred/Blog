﻿def Login():
  #Opens the specified URL in a running instance of the specified browser.
  Browsers.Item[btChrome].Navigate("https://qa-task.backbasecloud.com/#/login")
  #Maximizes the specified Window object.
  Aliases.browser.BrowserWindow.Maximize()
  #Clicks the 'textbox' control.
  Aliases.browser.pageBblog.form.fieldset.textbox.Click()
  #Sets the text 'sqa.fred@gmail.com' in the 'textbox' text editor.
  Aliases.browser.pageBblog.form.fieldset.textbox.SetText("sqa.fred@gmail.com")
  #Enters '[Tab]' in the 'textbox' object.
  Aliases.browser.pageBblog.form.fieldset.textbox.Keys("[Tab]")
  #Sets the text Project.Variables.Password1 in the 'passwordbox' text editor.
  Aliases.browser.pageBblog.form.fieldset2.passwordbox.SetText(Project.Variables.Password1)
  #Clicks the 'buttonSignIn' button.
n.ClickButton()  Aliases.browser.pageBblog.buttonSignI
